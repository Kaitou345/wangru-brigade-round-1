#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

const int RED_PIN = 4;
const int BLUE_PIN = 5;

void setup() {
  Serial.begin(115200);

  pinMode(RED_PIN, INPUT);
  pinMode(BLUE_PIN, INPUT);

  // ESP32-S3 I2C pins
  Wire.begin(8, 9);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 allocation failed");
    while (true);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
}

void loop() {

  int redState = digitalRead(RED_PIN);
  int blueState = digitalRead(BLUE_PIN);

  int totalPower = 0;

  if (blueState == HIGH)
    totalPower += 5;

  if (redState == HIGH)
    totalPower += 10;

  display.clearDisplay();

  display.setCursor(0, 0);
  display.setTextSize(1);

  display.println("SMART OFFICE");
  display.println("--------------------");

  display.print("Blue LED : ");
  display.println(blueState ? "ON" : "OFF");

  display.print("Power    : ");
  display.print(blueState ? 5 : 0);
  display.println("W");

  display.println();

  display.print("Red LED  : ");
  display.println(redState ? "ON" : "OFF");

  display.print("Power    : ");
  display.print(redState ? 10 : 0);
  display.println("W");

  display.println("--------------------");

  display.print("Total: ");
  display.print(totalPower);
  display.println("W");

  display.display();

  Serial.print("Blue: ");
  Serial.print(blueState);

  Serial.print(" | Red: ");
  Serial.print(redState);

  Serial.print(" | Total: ");
  Serial.print(totalPower);
  Serial.println("W");

  delay(200);
}